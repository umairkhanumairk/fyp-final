import { Card } from "flowbite-react";
import { useState } from "react";
import { BACKEND_URL } from "../lib/vars.ts";
import { Cookies } from "../lib/globals.ts";
import axios from 'axios'

export default () => {
  const [message, setMessage]: any = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const SignUp = async (user: any) => {
    const form = new FormData();
    for (let key in user) form.append(key, user[key]);
    setMessage(false);
    await axios
      .post(`${BACKEND_URL}/sign-up`, form)
      .then((res: any) => {
        res = res.data;
        if (res.success === 0)
          setMessage({ message: res.message, variant: "danger" });
        else {
          setMessage({ message: res.message, variant: "success" });
          delete user.password;
          delete user.repassword;
          const u = { ...user, _id: res._id, avatar: res.avatar };
          Cookies.set("user", u, { expires: 356 });
          window.location.href = '/'
        }
      })
      .catch((err: any) => {
        console.error(err);
        setMessage({ message: err.message, variant: "danger" });
      });
  };
  const Login = async (user: any) => {
    const form = new FormData();
    for (let key in user) form.append(key, user[key]);
    setMessage(false);
    console.log('hello world', user)
    await axios
      .post(`${BACKEND_URL}/login`, form)
      .then((res: any) => {
        res = res.data;
        if (res.success === 0)
          setMessage({ message: res.message, variant: "danger" });
        else {
          setMessage({ message: res.message, variant: "success" });
          delete user.password;
          delete user.repassword;
          Cookies.set("user", res.user, { expires: 356 });
          window.location.href = '/'
        }
      })
      .catch((err: any) => {
        console.error(err);
        setMessage({ message: err.message, variant: "danger" });
      });
  };
  const handleForm = async (form: any) => {
    form.preventDefault();
    const username = form.target["fullname"].value;
    const email = form.target["email"].value;
    const password = form.target["password"].value;
    const repassword = form.target["re-password"].value;
    let avatar = form.target["avatar"].files;
    if (avatar.length > 0) avatar = avatar[0];
    else avatar = null;
    let m = null;
    if (username === "") m = "Please enter username.";
    else if (email === "") m = "Please enter your email address";
    else if (password === "") m = "Please enter new password.";
    else if (password.length < 8)
      m = "Please enter password more than 8 chars.";
    else if (password !== repassword) m = "password is not matched.";
    if (m) setMessage({ message: m, variant: "alert" });
    else SignUp({ fullname:username, email, password, repassword, avatar });
  };
  const loginForm = async (form:any) => {
    form.preventDefault();
    const email = form.target["email"].value;
    const password = form.target["password"].value;
    await Login({'user':email, password})
  }
  return isLogin ? (
    <Card id="contact" className="">
      <h1 className="text-2xl font-bold uppercase my-2 w-max">Login Now</h1>
      <form className="w-full m-auto md:w-6/12" onSubmit={loginForm}>
                <div className="relative z-0 w-full mb-5 group">
          <input
            type="email"
            name="email"
            id="email"
            className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
            placeholder=" "
            required
          />
          <label
            htmlFor="email"
            className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
          >
            Enter your email address
          </label>
        </div>
        <div className="flex">
          

          <div className="relative z-0 w-full mb-5 group">
            <input
              type="password"
              name="password"
              id="password"
              className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
              placeholder=" "
              required
            />
            <label
              htmlFor="password"
              className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
            >
              Enter your password
            </label>
          </div>
        </div>
        <button
          type="submit"
          className="mt-4 mb-3 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
        >
         Login 
        </button>
        {message && (
          <span
            className={`block w-max px-3 py-1 text-black rounded font-semibold text-sm ${
              message.variant === "alert"
                ? "bg-orange-300"
                : message.variant === "danger"
                ? "bg-red-400"
                : "bg-green-400"
            }`}
          >
            {message.message}
          </span>
        )}
        <span className="block my-2">
          if you not have any account then please <button className="text-blue-500 font-bold capitalize" type="button" onClick={() => setIsLogin(false)}>sign up</button>.
        </span>
      </form>
    </Card>

  ) : (
    <Card id="contact" className="">
      <h1 className="text-2xl font-bold uppercase my-2 w-max">Register Now</h1>
      <form className="w-full m-auto md:w-6/12" onSubmit={handleForm}>
        <div className="mb-2">
          <label htmlFor="avatar" className="fonts block text-sm">
            Profile image
          </label>
          <input type="file" name="avatar" id="avatar" accept="image/*" />
        </div>

        <div className="relative z-0 w-full mb-5 group">
          <input
            type="text"
            name="fullname"
            id="fullname"
            className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
            placeholder=" "
            required
          />
          <label
            htmlFor="fullname"
            className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
          >
            Enter your fullname
          </label>
        </div>
        <div className="relative z-0 w-full mb-5 group">
          <input
            type="email"
            name="email"
            id="email"
            className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
            placeholder=" "
            required
          />
          <label
            htmlFor="email"
            className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
          >
            Enter your email address
          </label>
        </div>
        <div className="flex">
          <div className="relative z-0 w-full mb-5 group mr-3">
            <input
              type="password"
              name="password"
              id="password"
              className="block  py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
              placeholder=" "
              required
            />
            <label
              htmlFor="password"
              className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
            >
              Enter your password
            </label>
          </div>

          <div className="relative z-0 w-full mb-5 group">
            <input
              type="password"
              name="re-password"
              id="re-password"
              className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
              placeholder=" "
              required
            />
            <label
              htmlFor="re-password"
              className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
            >
              Enter your password again
            </label>
          </div>
        </div>
        <button
          type="submit"
          className="mt-4 mb-3 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
        >
          Submit
        </button>
        {message && (
          <span
            className={`block w-max px-3 py-1 text-black rounded font-semibold text-sm ${
              message.variant === "alert"
                ? "bg-orange-300"
                : message.variant === "danger"
                ? "bg-red-400"
                : "bg-green-400"
            }`}
          >
            {message.message}
          </span>
        )}
        <span className="block my-2">
          I have already created account just <button className="text-blue-500 font-bold capitalize" type="button" onClick={() => setIsLogin(true)}>sign In</button>.
        </span>
      </form>
    </Card>
  );
};

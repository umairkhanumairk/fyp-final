import { Card } from "flowbite-react";
import { BACKEND_URL } from "../lib/vars";
import UserIcon from '../assets/user.svg'
import { Cookies } from "../lib/globals";


export default ({User}:any) => {
  const handleLogout = () =>{
    Cookies.delete('user')
    window.location.href = '/'
  }
  return (
    <Card id="contact" style={{width: 'max-content'}}>
      <h1 className="text-2xl font-bold uppercase my-2 w-max text-center">Hello {User.fullname}</h1>
      <form className="w-full m-auto md:w-6/12">
      <div className="flex items-center" style={{width: 'max-content'}}>
        <div style={{width: 60, height:60,borderRadius:'50%', border: '2px solid grey', overflow:'hidden'}}>
            <img src={User.avatar && User.avatar != '' ? BACKEND_URL + User.avatar : UserIcon} style={{width: '100%', height: '100%', objectFit: 'cover', }}/>
        </div>
        <div style={{marginLeft: '10px'}} className="flex flex-col">
            <span style={{textTransform: 'capitalize', fontSize: '18px'}}>{User.fullname}</span>
            <span className="text-sm">{User.email}</span>
        </div>
        </div>
        <button
          type="button"
          onClick={handleLogout}
          className="mt-4 mb-3 text-white font-medium text-sm w-full sm:w-auto px-5 py-2 text-center  flex items-center justify-center"
        style={{width: '100%', textAlign:'center', border: '2px solid orangered', justifyContent:'center', borderRadius: '6px'}}
        >
          <svg style={{marginRight: '5px'}} xmlns="http://www.w3.org/2000/svg" width="1.2em" height="1.2em" viewBox="0 0 24 24"><path fill="currentColor" d="M5 5h6c.55 0 1-.45 1-1s-.45-1-1-1H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h6c.55 0 1-.45 1-1s-.45-1-1-1H5z"/><path fill="currentColor" d="m20.65 11.65l-2.79-2.79a.501.501 0 0 0-.86.35V11h-7c-.55 0-1 .45-1 1s.45 1 1 1h7v1.79c0 .45.54.67.85.35l2.79-2.79c.2-.19.2-.51.01-.7"/></svg>
          Logout
        </button>
     
      </form>
    </Card>
  )
}
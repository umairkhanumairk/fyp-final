import axios from "axios"
import { Card } from "flowbite-react"
import { BACKEND_URL } from "../lib/vars"
import {useEffect, useState} from 'react'
import { life } from "../lib/globals"

export default ({ languageClass }: any) => {
    const [items, setItems ]:any = useState([])
    const getHistory = async () => {
        await axios.get(BACKEND_URL + '/get-history')
        .then(res => {
            res = res.data
            console.log(res)
            setItems(res)
        })
        .catch(err => {
            console.error(err)
        })
    }
    useEffect(() => {
        getHistory()
    })
    
    return (
        <section id="cards" className={`bg-white dark:bg-gray-900 ${languageClass === 'arabic' ? 'arabic_dir' : 'english_dir'}`}>
            <div className="grid max-w-screen-xl px-4 py-8 mx-auto lg:gap-8 xl:gap-0 lg:py-12">
                <div className="m-auto place-self-center flex items-stretch flex-wrap justify-center w-full">
                    {items.map((item: any, i: number) => (
                        <Card key={++i} className="max-w-sm m-1 bg-blue-100">
                            <h5 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                               {/* {item.user[0].fullname}  */}
                               <span className="block text-sm font-normal text-slate-400 dark:text-slate-400 "> ask {life(item.createdAt).from()}
                               </span>
                            </h5>
                            <p className="font-normal text-gray-700 dark:text-gray-400">
                               {/* {item.answers[0]} */}
                            </p>
                        </Card>
                    ))}
                </div>
            </div>
        </section>
    )
}
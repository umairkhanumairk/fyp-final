import { DarkThemeToggle, Navbar } from "flowbite-react";

export default () => {
  return (
    <Navbar fluid>
      <Navbar.Brand href="https://flowbite-react.com">
        <span className="self-center whitespace-nowrap text-xl font-semibold text-black dark:text-white">
          Islamic QA
        </span>
      </Navbar.Brand>
      <div className="flex md:order-2">
        <Navbar.Toggle />
      </div>
      <Navbar.Collapse>
        <Navbar.Link className="mt-2" href="/" active>
          Home
        </Navbar.Link>
        <Navbar.Link>
          <DarkThemeToggle />
        </Navbar.Link>
      </Navbar.Collapse>
    </Navbar>
  );
};

import { Card } from "flowbite-react";
import { useState } from "react";
import axios from 'axios'
import { BACKEND_URL } from "../lib/vars";
export default ({User}:any) => {
  const [text, setText] = useState('')
  const [loading, setLoading] =useState(false)
  const handleForm = async () => {
    // console.log(text)
    const form = new FormData()
    form.append('text', text)
    form.append('user_id', User._id)
    setLoading(true)
    await axios.post(BACKEND_URL + '/ask', form)
    .then(res => {
      console.log(res.data)
      setLoading(false)
    })
    .catch(err => {console.error(err);setLoading(false)})
  }
  return (
    <Card id="contact" className="">
      <h1 className="text-2xl font-bold">Ask question about Islam</h1>
      <form className="w-full m-auto md:w-6/12">
        <label
          htmlFor="message"
          className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
        >
          Enter your Question
        </label>
        <textarea
          id="message"
          rows={4}
          onChange={(e) => setText(e.target.value)}
          className="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          placeholder="Write your question here..."
        ></textarea>
        <button
          type="button"
          onClick={handleForm}
          className="mt-4 mb-3  text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
        >
          {loading ? 'Loading....' : 'Ask'}
        </button>
      </form>
    </Card>
  );
};
